package com.example.cetej5trabalho1.DAO;

public class HibernateUtil {

}
